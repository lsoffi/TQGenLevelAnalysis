# Running Fireworks

```
cmsShow <my_file.root> -c <my_config.fwc>
```

All info in this twiki:
https://twiki.cern.ch/twiki/bin/view/CMSPublic/WorkBookFireworksUserGuide
